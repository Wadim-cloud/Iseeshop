const load = async ({ locals }) => {
  return {
    session: locals.session
  };
};
export {
  load
};
