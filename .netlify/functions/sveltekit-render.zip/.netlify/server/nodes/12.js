

export const index = 12;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/settings/admin/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/12.Dtwkfr6C.js","_app/immutable/chunks/CWj6FrbW.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/CgpLTG9e.js","_app/immutable/chunks/C_m-qMmZ.js","_app/immutable/chunks/CVxkZOGS.js","_app/immutable/chunks/B6FZq7_G.js","_app/immutable/chunks/CeoSvVGI.js","_app/immutable/chunks/Bs1xm8oX.js","_app/immutable/chunks/CKI-jMsq.js","_app/immutable/chunks/BEUgLf7p.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/CRvbaXOV.js","_app/immutable/chunks/4hlrb4d8.js"];
export const stylesheets = ["_app/immutable/assets/12.Dhf4GTUo.css"];
export const fonts = [];
