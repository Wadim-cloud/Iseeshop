import * as server from '../entries/pages/gallery/_page.server.ts.js';

export const index = 6;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/gallery/_page.svelte.js')).default;
export { server };
export const server_id = "src/routes/gallery/+page.server.ts";
export const imports = ["_app/immutable/nodes/6.C6-kLq3a.js","_app/immutable/chunks/B-NZGOte.js","_app/immutable/chunks/Cd5A3r1K.js","_app/immutable/chunks/BJhGwTA4.js","_app/immutable/chunks/BHD2twxc.js","_app/immutable/chunks/D0OOgfdb.js","_app/immutable/chunks/BnAYVnrU.js","_app/immutable/chunks/BxK8aaWw.js","_app/immutable/chunks/CL7b9zr9.js","_app/immutable/chunks/YOJFXgiR.js","_app/immutable/chunks/CPdt6UWS.js","_app/immutable/chunks/BUqy5JzF.js","_app/immutable/chunks/FpvPSTWz.js","_app/immutable/chunks/B2jQ_eJN.js","_app/immutable/chunks/DOAsa2zh.js","_app/immutable/chunks/ok0BmAN_.js","_app/immutable/chunks/C1FmrZbK.js"];
export const stylesheets = ["_app/immutable/assets/Floating3DModel.BnJRNIkG.css","_app/immutable/assets/6.BuaVk01n.css"];
export const fonts = [];
