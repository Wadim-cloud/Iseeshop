

export const index = 7;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/shaders-filters/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/7.CbOuzdbS.js","_app/immutable/chunks/DPmhzSt5.js","_app/immutable/chunks/BDHGhfTE.js","_app/immutable/chunks/CHpTJ84V.js","_app/immutable/chunks/CvTsB6m-.js","_app/immutable/chunks/CTjs_13Y.js","_app/immutable/chunks/1K336M6a.js","_app/immutable/chunks/D02H29ki.js","_app/immutable/chunks/BvDJoXBx.js","_app/immutable/chunks/RZ2m-Vl7.js","_app/immutable/chunks/B2jQ_eJN.js"];
export const stylesheets = ["_app/immutable/assets/7.5or3_gG0.css"];
export const fonts = [];
