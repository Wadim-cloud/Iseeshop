

export const index = 7;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/shaders-filters/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/7.Dm1Fhpxf.js","_app/immutable/chunks/B-NZGOte.js","_app/immutable/chunks/Cd5A3r1K.js","_app/immutable/chunks/BJhGwTA4.js","_app/immutable/chunks/BHD2twxc.js","_app/immutable/chunks/CL7b9zr9.js","_app/immutable/chunks/YOJFXgiR.js","_app/immutable/chunks/CzEU2NIM.js","_app/immutable/chunks/BUqy5JzF.js","_app/immutable/chunks/B2jQ_eJN.js"];
export const stylesheets = ["_app/immutable/assets/7.5or3_gG0.css"];
export const fonts = [];
