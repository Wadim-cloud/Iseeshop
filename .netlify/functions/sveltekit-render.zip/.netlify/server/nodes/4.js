

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/auth/callback/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.C-Qqa_tj.js","_app/immutable/chunks/DPmhzSt5.js","_app/immutable/chunks/BDHGhfTE.js","_app/immutable/chunks/CHpTJ84V.js","_app/immutable/chunks/JMSSoVz2.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/DoXARqE7.js","_app/immutable/chunks/DH2AK175.js"];
export const stylesheets = [];
export const fonts = [];
