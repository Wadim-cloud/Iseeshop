

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/auth/callback/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.D-ynxJv4.js","_app/immutable/chunks/B-NZGOte.js","_app/immutable/chunks/Cd5A3r1K.js","_app/immutable/chunks/BJhGwTA4.js","_app/immutable/chunks/ok0BmAN_.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/D0OOgfdb.js","_app/immutable/chunks/BnAYVnrU.js"];
export const stylesheets = [];
export const fonts = [];
