

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/auth/callback/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.DP9xMTm1.js","_app/immutable/chunks/CWj6FrbW.js","_app/immutable/chunks/69_IOA4Y.js","_app/immutable/chunks/DIeogL5L.js","_app/immutable/chunks/CgpLTG9e.js","_app/immutable/chunks/CVxkZOGS.js","_app/immutable/chunks/CKI-jMsq.js","_app/immutable/chunks/BEUgLf7p.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/CRvbaXOV.js","_app/immutable/chunks/4hlrb4d8.js"];
export const stylesheets = [];
export const fonts = [];
