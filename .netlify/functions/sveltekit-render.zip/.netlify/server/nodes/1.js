

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.H3iujTKJ.js","_app/immutable/chunks/B-NZGOte.js","_app/immutable/chunks/Cd5A3r1K.js","_app/immutable/chunks/BJhGwTA4.js","_app/immutable/chunks/BHD2twxc.js","_app/immutable/chunks/D0OOgfdb.js","_app/immutable/chunks/BnAYVnrU.js"];
export const stylesheets = [];
export const fonts = [];
