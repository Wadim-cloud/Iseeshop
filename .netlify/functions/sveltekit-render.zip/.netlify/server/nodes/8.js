

export const index = 8;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/todo/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/8.CG1-ef8e.js","_app/immutable/chunks/B-NZGOte.js","_app/immutable/chunks/Cd5A3r1K.js","_app/immutable/chunks/BJhGwTA4.js","_app/immutable/chunks/BHD2twxc.js","_app/immutable/chunks/YOJFXgiR.js","_app/immutable/chunks/CzEU2NIM.js","_app/immutable/chunks/ok0BmAN_.js","_app/immutable/chunks/C1FmrZbK.js","_app/immutable/chunks/D0OOgfdb.js","_app/immutable/chunks/BnAYVnrU.js","_app/immutable/chunks/CPdt6UWS.js","_app/immutable/chunks/C4-Fto9l.js","_app/immutable/chunks/BxK8aaWw.js"];
export const stylesheets = ["_app/immutable/assets/8.dAbjOeNq.css"];
export const fonts = [];
