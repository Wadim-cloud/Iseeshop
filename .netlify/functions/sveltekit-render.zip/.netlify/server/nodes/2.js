

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.D3-zkNNj.js","_app/immutable/chunks/DPmhzSt5.js","_app/immutable/chunks/BDHGhfTE.js","_app/immutable/chunks/CHpTJ84V.js","_app/immutable/chunks/CvTsB6m-.js","_app/immutable/chunks/1K336M6a.js","_app/immutable/chunks/ChMpMzq7.js","_app/immutable/chunks/DH2AK175.js","_app/immutable/chunks/eNzXqwWJ.js","_app/immutable/chunks/DoXARqE7.js","_app/immutable/chunks/DR4qTk9g.js","_app/immutable/chunks/RZ2m-Vl7.js","_app/immutable/chunks/JMSSoVz2.js","_app/immutable/chunks/C1FmrZbK.js"];
export const stylesheets = ["_app/immutable/assets/CanvasShader.DGCYF2tG.css","_app/immutable/assets/2.KnZycZjH.css"];
export const fonts = [];
