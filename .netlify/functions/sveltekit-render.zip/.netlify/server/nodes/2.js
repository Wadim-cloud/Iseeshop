

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.bSDcId1K.js","_app/immutable/chunks/B-NZGOte.js","_app/immutable/chunks/Cd5A3r1K.js","_app/immutable/chunks/BJhGwTA4.js","_app/immutable/chunks/BHD2twxc.js","_app/immutable/chunks/CL7b9zr9.js","_app/immutable/chunks/DOAsa2zh.js","_app/immutable/chunks/C4-Fto9l.js","_app/immutable/chunks/BxK8aaWw.js","_app/immutable/chunks/BnAYVnrU.js","_app/immutable/chunks/DgNV32f5.js","_app/immutable/chunks/D0OOgfdb.js","_app/immutable/chunks/lF2x1chg.js","_app/immutable/chunks/BUqy5JzF.js","_app/immutable/chunks/ok0BmAN_.js","_app/immutable/chunks/C1FmrZbK.js"];
export const stylesheets = ["_app/immutable/assets/CanvasShader.DGCYF2tG.css","_app/immutable/assets/2.uElmQ1ai.css"];
export const fonts = [];
